$(document).ready(function(){
	$('.brandsSliderContainer').slick({
		slidesToShow: 5,
		autoplay: true,
		autoplaySpeed: 3000,
		arrows: false,
	});
});
	